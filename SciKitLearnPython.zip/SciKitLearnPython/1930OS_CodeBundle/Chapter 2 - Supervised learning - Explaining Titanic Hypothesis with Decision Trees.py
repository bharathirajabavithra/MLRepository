# -*- coding: utf-8 -*-
"""
Created on Wed Apr 26 20:25:20 2017

@author: Raja2
"""
import csv
import numpy as np
import matplotlib.pyplot as plt

titanic_X, titanic_y = [], []
with open('data/titanic.csv', newline='') as csvfile:
    titanic_reader = csv.reader(csvfile, delimiter=',', quotechar='"')
    row = titanic_reader.__next__()
    feature_names = np.array(row)
    
    for row in titanic_reader:
         titanic_X.append(row)
         titanic_y.append(row[2])
    titanic_X = np.array(titanic_X)
    titanic_y = np.array(titanic_y)
#    print(feature_names,titanic_X)
    # we keep the class, the age and the sex
titanic_X = titanic_X[:, [1, 4, 10]]
feature_names = feature_names[[1, 4, 10]]

# We have missing values for age
# Assign the mean value
ages = titanic_X[:, 1]
mean_age = np.mean(titanic_X[ages != 'NA', 1].astype(np.float))
titanic_X[titanic_X[:, 1] == 'NA', 1] = mean_age

# Encode sex 
from sklearn.preprocessing import LabelEncoder
enc = LabelEncoder()
label_encoder = enc.fit(titanic_X[:, 2])
#print("Categorical classes:", label_encoder.classes_)
integer_classes = label_encoder.transform(label_encoder.classes_)
#print("Integer classes:", integer_classes)
titanic_X[:, 2] = label_encoder.transform(titanic_X[:, 2])

enc = LabelEncoder()
label_encoder = enc.fit(titanic_X[:, 0])
#print("Categorical classes:", label_encoder.classes_)
integer_classes = label_encoder.transform(label_encoder.classes_)
#print("Integer classes:", integer_classes)
titanic_X[:, 0] = label_encoder.transform(titanic_X[:, 0])

#print(feature_names)
#print(titanic_X[0], titanic_y[0])

from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(titanic_X, titanic_y, test_size=0.25, random_state=33)

from sklearn import svm
clf = svm.SVC(kernel='rbf', gamma=2)
clf.fit(X_train,y_train)
print(X_test[:2,:])
print("Output is ")
print(clf.predict(X_test[:2,:]))

from sklearn import metrics
def measure_performance(X,y,clf, show_accuracy=True, show_classification_report=True, show_confusion_matrix=True):
    y_pred=clf.predict(X)   
    if show_accuracy:
        print("Accuracy:{0:.3f}".format(metrics.accuracy_score(y,y_pred)),"\n")

    if show_classification_report:
        print("Classification report")
        print(metrics.classification_report(y,y_pred),"\n")
        
    if show_confusion_matrix:
        print("Confusion matrix")
        print(metrics.confusion_matrix(y,y_pred),"\n")
        
measure_performance(X_train,y_train,clf, show_classification_report=True, show_confusion_matrix=True)
from sklearn import preprocessing
standard_scalar= preprocessing.StandardScaler()
x_std=standard_scalar.fit(X_train)
from sklearn.manifold import TSNE
tsne=TSNE(n_components=2, random_state= 2)
x_train_std=tsne.fit_transform(x_std)

markers = {'s','d','o'}
color_maps = {0:'red',1:'green',2:'blue'}
plt.figure()



