# -*- coding: utf-8 -*-
"""
Created on Mon Apr 24 20:50:32 2017

@author: Raja2
"""
"""Introduction into machine learning"""
#import libs
import sklearn as sk #scikit-learn lib
import numpy as np #numeric py lib
import matplotlib.pyplot as plt # plots lib
#
#Load Iris dataset
from sklearn import datasets
iris = datasets.load_iris()
X_iris, y_iris = iris.data, iris.target
#print (X_iris.shape, y_iris.shape)
#print (X_iris[0], y_iris[0])
#
"""Create training , testing partitions and standarize data."""
from sklearn.cross_validation import train_test_split
from sklearn.preprocessing import StandardScaler
# Get dataset with only the first two attributes
X, y = X_iris[:,:2], y_iris



