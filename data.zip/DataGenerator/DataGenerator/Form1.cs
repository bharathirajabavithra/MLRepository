﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;

namespace DataGenerator
{
    public partial class Form1 : Form
    {
        Thread thread;
        public int Random(int min,int max)
        {
            Random random = new Random();
            return random.Next(min, max);
        }
        public Form1()
        {
            InitializeComponent();
        }


        List<string> DateSting = new List<string>();
         
        private void button1_Click(object sender, EventArgs e)
        {
           // string dateTime = "05/01/2017 08:50:00";
            ThreadStart trd = new ThreadStart(dld);
            thread = new Thread(trd);
            thread.Start();
           
        }
        void dld()
        {
            for (int i = 0; i < 30; i++)
            {
                button2.Text = i.ToString();
                 D:
                string ns = string.Format("05/{0}/2017", Random(1, 31));
                if (DateSting.Contains(ns))
                {
                    label1.Text = "looping";
                    if (i != 29)
                    {
                        goto D;
                    }
                }
                DateSting.Add(ns);
                label1.Text = "No Looping";
                //DateTimeOffset date = new DateTimeOffset(2017, 5, Check(1, 6), Random(9, 18), Random(0, 60), 0, TimeSpan.Zero);
                perRequest(ns, Random(40, 140));
            }
           
        }
        void perRequest(string dateTime, int n)
        {
           // DateTime dt = Convert.ToDateTime(dateTime); 
            int C = dataGridView1.Rows.Count - 1;
            for (int i = C; i < (C+n); i++)
            {
                button1.Text = i.ToString();
                dataGridView1.Rows.Add();
                int HH=Random(09, 18);
                int MM=Random(00, 60);
               // DateTime dt = Convert.ToDateTime(dateTime + string.Format(" {0}:{1}:00", HH, MM)); 
                DateTime dt = Convert.ToDateTime(dateTime);
                //if (iss)
                //{
                //   // MessageBox.Show(HH + ":" + MM);
                //}
                dataGridView1[0, i].Value = i+1;
                dataGridView1[1, i].Value = dt.ToShortDateString();
                dataGridView1[2, i].Value = n;
                dataGridView1[3, i].Value = Random(1, 11);
            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            foreach (string item in DateSting)
            {
                d(item);
            }
            ex();
            Indi();
            SaveDataGridViewToCSV((Random(1, 100) * Random(1, 100)).ToString());
            label1.Text = "Completed-+";
        }
        void d(string ss)
        {
            
            List<int> cou=new List<int>();
            DateTime s = Convert.ToDateTime(ss);
            for (int j = 0; j < 10; j++)
            {
                
                int lslsls = 0;
                int lds = 0;
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    //dataGridView2.Rows.Add();
                    //dataGridView2[1, i].Value = i;

                    label1.Text = s.ToShortDateString() + " " + (j + 1).ToString();
                    if ((dataGridView1[1, i].Value.ToString().Contains(s.ToShortDateString())) && (dataGridView1[3, i].Value.ToString()==(j+1).ToString()))
                    {
                        
                        lds = (dataGridView2.Rows.Count - 1);
                        dataGridView2.Rows.Add();
                        dataGridView2[0, lds].Value = dataGridView1[0, i].Value.ToString();
                        dataGridView2[1, lds].Value = dataGridView1[1, i].Value.ToString();
                        dataGridView2[2, lds].Value = dataGridView1[2, i].Value.ToString();
                        dataGridView2[3, lds].Value = dataGridView1[3, i].Value.ToString();
                        lslsls = lslsls + 1;
                    }
                }
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    string ssddfsf="";
                    try
                    {
                       ssddfsf = dataGridView2[4, i].Value.ToString();
                    }
                    catch
                    {
                    }
                    if (ssddfsf=="")
                    {
                        dataGridView2[4, i].Value = lslsls;
                        Thread.Sleep(10);
                        int r=Random(1, 17);
                        dataGridView2[5, i].Value = r;
                        if (r > 8)
                        {
                            dataGridView2[6, i].Value = 1;
                            dataGridView2[9, i].Value = s.AddDays(1).ToShortDateString();

                        }
                        else
                        {
                            dataGridView2[6, i].Value = 0;
                            dataGridView2[9, i].Value = s.ToShortDateString();
                        }

                    }
                }
            }
        }
        void ex()
        {
            List<string> DiDate=new List<string>();
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                if (!DiDate.Contains(dataGridView2[9, i].Value.ToString()))
                {
                    DiDate.Add(dataGridView2[9, i].Value.ToString());
                }
            }
            
            foreach(string item in DiDate)
            {
                int Count = 0;
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    if (dataGridView2[9, i].Value.ToString() == item)
                    {
                        Count = Count + 1;
                        
                    }
                }
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                {
                    try
                    {
                        if (dataGridView2[9, i].Value.ToString() == item)
                        {
                            dataGridView2[7, i].Value = Count;
                        }
                    }
                    catch
                    {
                        break;
                        
                    }
                     
                }

            }

            
        }

        void Indi()
        {
             List<string> DiDate=new List<string>();
            for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
            {
                if (!DiDate.Contains(dataGridView2[9, i].Value.ToString()))
                {
                    DiDate.Add(dataGridView2[9, i].Value.ToString());
                }
            }

            foreach (string item in DiDate)
            {
                for (int k = 0; k < 10; k++)
                {
                    int Count = 0;
                    for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                    {
                        if ((dataGridView2[9, i].Value.ToString() == item) && ((k+1).ToString()==dataGridView2[3,i].Value.ToString()))
                        {
                            Count = Count + 1;

                        }
                    }
                    for (int i = 0; i < dataGridView2.Rows.Count - 1; i++)
                    {
                        label1.Text = dataGridView2[9, i].Value.ToString() + " " + item + " " + (k + 1).ToString() + " " + dataGridView2[3, i].Value.ToString();
                        if ((dataGridView2[9, i].Value.ToString() == item) && ((k + 1).ToString() == dataGridView2[3, i].Value.ToString()))
                        {
                            dataGridView2[8, i].Value = Count;
                        }
                    }
                }
               
            }

        }

        void SaveDataGridViewToCSV(string filename)
        {
            filename = filename + ".csv";
            // Choose whether to write header. Use EnableWithoutHeaderText instead to omit header.
            dataGridView2.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            // Select all the cells
            dataGridView2.SelectAll();
            // Copy selected cells to DataObject
            DataObject dataObject = dataGridView2.GetClipboardContent();
            // Get the text of the DataObject, and serialize it to a file
            File.WriteAllText(filename, dataObject.GetText(TextDataFormat.CommaSeparatedValue));
        }
    
    }
}
