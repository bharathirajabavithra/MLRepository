# -*- coding: utf-8 -*-
"""
Created on Sun May  7 17:15:35 2017

@author: Raja2
"""
import numpy as np
from matplotlib import pyplot as plt
import pandas as pd
df=pd.read_csv('data\841.csv')
OPR=df;

df['Rdate'] = pd.to_datetime(df['Rdate'])
sorted_df=df.sort('Rdate')
process_input_rate=sorted_df.groupby('Rdate').IPRPD.agg(['count'])

OPR['Ddate']=pd.to_datetime(df['Ddate'])
sddf=OPR.sort('Ddate')
ProcessRate=OPR.groupby('Ddate').PCRPD.agg(['count'])

#Nparray_process_rate=np.array(ProcessRate)
#print(Nparray_process_rate.mean())
#Nparray_input_rate=np.array(process_input_rate)

plt.plot(np.array(process_input_rate))
plt.plot(np.array(ProcessRate))
plt.plot(np.repeat((np.array(process_input_rate)).mean(),31))
plt.plot(np.repeat((np.array(ProcessRate)).mean(),31))
plt.ylabel('request count')
plt.xlabel('May 2017')
plt.legend(['y = input rate per on each day', 'y = process rate on each day','y = Avg input rate','y = Avg process rate'], loc='upper right')
fig = plt.gcf()
fig.set_size_inches(8,4)
plt.show()



